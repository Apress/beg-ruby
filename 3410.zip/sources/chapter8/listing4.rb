begin
  puts 10 / 0
rescue
  puts "You caused an error!"
end

