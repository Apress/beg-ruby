File.open("text.txt", "w") do |f|
  f.puts "This is a test"
end

