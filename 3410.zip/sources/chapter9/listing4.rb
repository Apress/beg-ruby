f = File.open("text.txt")
puts f.pos
puts f.gets
puts f.pos

