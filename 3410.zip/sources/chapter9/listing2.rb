File.open("text.txt").each { |line| puts line }
