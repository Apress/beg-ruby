require 'rubygems'
require 'hpricot'
puts "Hpricot installed successfully" if Hpricot
