require 'ostruct'
person = OpenStruct.new
person.name = "Fred Bloggs"
person.age = 25
