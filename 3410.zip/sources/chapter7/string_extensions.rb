class String
  def vowels
    self.scan(/[aeiou]/i)
  end
end
