require 'a'
puts "Hello from b.rb"
require 'a'
puts "Hello again from b.rb"
