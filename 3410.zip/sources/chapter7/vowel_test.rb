require 'string_extensions'
puts "This is a test".vowels.join('-')
