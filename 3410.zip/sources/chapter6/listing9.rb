class String
  def length
    20
  end
end

puts "This is a test".length
puts "a".length
puts "A really long line of text".length
