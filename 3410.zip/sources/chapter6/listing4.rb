def basic_method
  x = 50
  puts x
end

x = 10
basic_method
puts x
