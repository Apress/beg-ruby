require 'mylib'
MyLib.hello_world
