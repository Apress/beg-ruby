class MyLib
  def MyLib.hello_world
    puts "Hello, world!"
  end
end
