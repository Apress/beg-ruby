fred = {
  'name' => 'Fred Elliott',
  'age' => 63,
  'gender' => 'male',
  'favorite painters' => ['Monet', 'Constable', 'Da Vinci']
}

puts fred['age']
puts fred['gender']
puts fred['favorite painters'].first
