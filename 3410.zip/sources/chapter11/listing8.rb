while x = gets
  puts "=> #{eval(x)}"
end

