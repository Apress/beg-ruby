x = system("date")
x = `date`

