class String
  def vowels
    scan(/[aeiou]/i)
  end
end

