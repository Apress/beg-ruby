#!/usr/bin/env ruby
puts ARGV.join('-')
